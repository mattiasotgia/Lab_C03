#include <cmath>
#include <fstream>
#include <vector>
#include <string>
#include <iostream>

#include <TApplication.h>
#include <TGraphErrors.h>
#include <TF1.h>
#include <TCanvas.h>
#include <TPad.h>
#include <TLatex.h>
#include <TStyle.h>
#include <TAxis.h>
#include <TMath.h>


using namespace std;

// recalling functions
// functions that may come useful
// -------------------------------------------------- statistics_values
/* media degli elementi del vettore */
double Media(vector<double>& v)
{
	double media = 0;
	for(int i = 0; i < v.size(); i++)
		media += v[i];
	return media / v.size();
}

/* media dei quadrati degli elementi del vettore */
double MediaQuadrati(vector<double>& v)
{
	double mediaQuadrati = 0;
	for(int i = 0; i < v.size(); i++)
		mediaQuadrati += v[i]*v[i];
	return mediaQuadrati / v.size();
}

/* varianza: <x^2> - <x>^2 */
double Varianza(vector<double>& v)
{
	double media = Media(v);
	double mediaQuadrati = MediaQuadrati(v);
	return mediaQuadrati - media*media;
}

/* varianza empirica: varianza * n/(n-1) */
double VarianzaEmpirica(vector<double>& v)
{
	double var = Varianza(v);
	return var * v.size()/(v.size() - 1);
}

/* deviazione standard: sqrt(varianza) */
double DevStandard(vector<double>& v)
{
	return sqrt(Varianza(v));
}


/* deviazione standard: sqrt(varianza) */
double DevStandardAdattata(vector<double>& v)
{
	return sqrt(VarianzaEmpirica(v));
}


/* deviazione standard: sqrt(varianza) */
double ErroreStandard(vector<double>& v)
{
	return DevStandardAdattata(v)/sqrt(v.size());
}


//	!!	ATTENZIONE:	NON TOCCARE FUNZIONI SOPRA!
//	!!				IL PROGRAMMA FINISCE QUI!
//	!!				ULTERIORI FUNZIONI SONO DA IMPLEMENTARE SOTTO \/ \/
//	!!

// Verifica della compatibilità per grandezze con errore STATISTICO
// Entrambe le misure devono avere errore sistematico!
// Criterio del 3(sigma)
string test_statErr(double g1, double g2, double eg1, double eg2){
	string r;
	auto r_num=abs(g1-g2)-(3*sqrt((eg1*eg1)+(eg2*eg2)));
	if ((abs(g1-g2)<(3*sqrt((eg1*eg1)+(eg2*eg2))))){
		r="COMPATIBILITA'";
	}else{
		r="DISCREPANZA: scarto tra |g1-g2| e |eg1+eg2| = "+to_string(abs(r_num)) ;
	}
	return r;
}



void plot(string __input__, string setDati, int PointCtr, TCanvas* c, int position, bool offset){

    ifstream in_dati(__input__);
	double x, d0, m;
	in_dati>>x>>d0>>m;
	double d=d0*1e-3;

	double eL0, e_t, e_d, e_m;
	in_dati>>eL0>>e_t>>e_d>>e_m;

	TGraphErrors _g1;
	_g1.GetXaxis()->SetTitle("Lunghezza L_{i} (m)");
	_g1.GetYaxis()->SetTitle("Peiodo T_{i} (s)");
	_g1.GetXaxis()->SetTitleOffset(0.85);
	_g1.GetXaxis()->SetTitleSize(0.06);
	_g1.GetYaxis()->SetTitleSize(0.06);

	for(int i=0; i<PointCtr; i++){

		string txt;
		in_dati>>txt;
		double L_i;
		in_dati>>L_i;
		double L=sqrt(pow(L_i*1e-3, 2)+pow((d)/(double)2, 2));
		double eL=((abs(d/(2*sqrt(d*d+4*L*L)))*eL0*1e-3)+(abs(2*L/sqrt(d*d+4*L*L)))*e_d*1e-3)/sqrt(3);
		in_dati>>txt;

		double t_10;
		vector<double> t10_v;
		for(int j=0; j<10; j++){

			in_dati>>t_10;
			t10_v.push_back(t_10/10);
		}

		_g1.SetPoint(i, L, Media(t10_v));
		_g1.SetPointError(i, eL, ErroreStandard(t10_v));
		t10_v.clear();
	}
	in_dati.close();

	string formula;
    if(offset){
        formula="[2]+2*[1]*sqrt(x/[0])";
    }else{
		formula="2*[1]*sqrt(x/[0])";

    }

	TF1 f1("f", formula.c_str(), 1.0, 2.0);

	if(offset){

		f1.SetParameter(2, 0);
		f1.SetParameter(0, 10);
		f1.FixParameter(1, M_PI);
	}else{

		f1.SetParameter(0, 10);
		f1.FixParameter(1, M_PI);
	}


    c->cd(position);
	gPad->Update();
	_g1.Draw("ap");
	_g1.Fit("f");
    gPad->Update();

    string g="g = "+to_string(f1.GetParameter(0))+" #pm "+to_string(f1.GetParError(0))+" m/s^{2}";
    string h="#bf{Dati "+setDati+"}";

	gStyle->SetTextFont(42);
	TLatex data_presa_dati;
	data_presa_dati.SetTextSize(0.04);
	data_presa_dati.DrawLatexNDC(0.14, 0.75, g.c_str());
	TLatex header;
	header.SetTextSize(0.05);
	header.DrawLatexNDC(0.14, 0.80, h.c_str());

	c->cd(position)->Draw();
}



// main function
int main(int argc, char** argv)
{
	// initial setup
    TApplication app("app", 0, 0);
	/*	NON TOCCARE SOPRA:	setup iniziale, lancia applicazione root
	 */

   	TCanvas* multiplot=new TCanvas("multiplot", "", 1100, 600);
    multiplot->Divide(3, 2, 0.00001, 0.00001);
    // gPad->Update();

    plot("../dati/eugenio_dormicchi.txt", "A", 5, multiplot, 1, false);
    plot("../dati/riccardo_pizzimbone.txt", "B", 5, multiplot, 2, false);
    plot("../dati/mattia_sotgia.txt", "C", 7, multiplot, 3, false);
    plot("../dati/eugenio_dormicchi.txt", "A", 5, multiplot, 4, true);
    plot("../dati/riccardo_pizzimbone.txt", "B", 5, multiplot, 5, true);
    plot("../dati/mattia_sotgia.txt", "C", 7, multiplot, 6, true);


    multiplot->SaveAs("multiplot.pdf");
    



	app.Run();	///////////////////////////////////////////////////////////END OF MAIN FUNCTION
    return 0;	///////////////////////////////////////////////////////////END OF MAIN FUNCTION
}