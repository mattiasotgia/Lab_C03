#include <cmath>
#include <fstream>
#include <vector>
#include <string>
#include <iostream>

#include <TApplication.h>
#include <TGraphErrors.h>
#include <TF1.h>
#include <TCanvas.h>
#include <TPad.h>
#include <TLatex.h>
#include <TStyle.h>
#include <TAxis.h>
#include <TMath.h>


using namespace std;

// recalling functions
// functions that may come useful
// -------------------------------------------------- statistics_values
/* media degli elementi del vettore */
double Media(vector<double>& v)
{
	double media = 0;
	for(int i = 0; i < v.size(); i++)
		media += v[i];
	return media / v.size();
}

/* media dei quadrati degli elementi del vettore */
double MediaQuadrati(vector<double>& v)
{
	double mediaQuadrati = 0;
	for(int i = 0; i < v.size(); i++)
		mediaQuadrati += v[i]*v[i];
	return mediaQuadrati / v.size();
}

/* varianza: <x^2> - <x>^2 */
double Varianza(vector<double>& v)
{
	double media = Media(v);
	double mediaQuadrati = MediaQuadrati(v);
	return mediaQuadrati - media*media;
}

/* varianza empirica: varianza * n/(n-1) */
double VarianzaEmpirica(vector<double>& v)
{
	double var = Varianza(v);
	return var * v.size()/(v.size() - 1);
}

/* deviazione standard: sqrt(varianza) */
double DevStandard(vector<double>& v)
{
	return sqrt(Varianza(v));
}


/* deviazione standard: sqrt(varianza) */
double DevStandardAdattata(vector<double>& v)
{
	return sqrt(VarianzaEmpirica(v));
}


/* deviazione standard: sqrt(varianza) */
double ErroreStandard(vector<double>& v)
{
	return DevStandardAdattata(v)/sqrt(v.size());
}

// -------------------------------------------------- statistic_plot_fit

// calcolo del chi quadro
double Chiquadro(vector<double>& x,
				 vector<double>& y,
				 vector<double>& ey,
				 double m,
				 double q)
{
	double chi2 = 0;
	for (int i = 0; i < x.size(); i++)
		chi2 += pow( ((y[i]-(m*x[i]+q)) / ey[i]), 2);
	return chi2;
}


// funzione intermedia per il metodo dei minimi quadrati
double S0(vector<double>& ey)
{
	double sum = 0;
	for(int i = 0; i < ey.size(); i++)
		sum += 1./(ey[i]*ey[i]);
	return sum;
}


// funzione intermedia per il metodo dei minimi quadrati
double S1(vector<double>& v1, vector<double>& ey)
{
	// assume v1 and ey have the same size
	double sum = 0;
	for(int i = 0; i < ey.size(); i++)
		sum += v1[i]/(ey[i]*ey[i]);
	return sum;
}


// funzione intermedia per il metodo dei minimi quadrati
double S2(vector<double>& v1, vector<double>& v2, vector<double>& ey)
{
	// assume v1 and ey have the same size
	double sum = 0;
	for(int i = 0; i < ey.size(); i++)
		sum += v1[i]*v2[i]/(ey[i]*ey[i]);
	return sum;
}


// Intercetta della retta calcolata con il metodo dei minimi quadrati
double Intercetta(vector<double>& x, vector<double>& y, vector<double>& ey)
{
	double s0 = S0(ey);
	double sx = S1(x, ey);
	double sy = S1(y, ey);
	double sxx = S2(x, x, ey);
	double sxy = S2(x, y, ey);
	return (sy*sxx - sx*sxy)/(sxx*s0 - sx*sx);
}


// Pendenza della retta calcolata con il metodo dei minimi quadrati
double Pendenza(vector<double>& x, vector<double>& y, vector<double>& ey)
{
	double s0 = S0(ey);
	double sx = S1(x, ey);
	double sy = S1(y, ey);
	double sxx = S2(x, x, ey);
	double sxy = S2(x, y, ey);
	return (s0*sxy - sx*sy)/(sxx*s0 - sx*sx);
}

// incertezza sull'intercetta
double ErrIntercetta(vector<double>& x, vector<double>& y, vector<double>& ey)
{
	double s0 = S0(ey);
	double sx = S1(x, ey);
	double sxx = S2(x, x, ey);
	return sqrt(sxx/(sxx*s0 - sx*sx));
}

// incertezza sulla pendenza
double ErrPendenza(vector<double>& x, vector<double>& y, vector<double>& ey)
{
	double s0 = S0(ey);
	double sx = S1(x, ey);
	double sxx = S2(x, x, ey);
	return sqrt(s0/(sxx*s0 - sx*sx));
}


//	!!	ATTENZIONE:	NON TOCCARE FUNZIONI SOPRA!
//	!!				IL PROGRAMMA FINISCE QUI!
//	!!				ULTERIORI FUNZIONI SONO DA IMPLEMENTARE SOTTO \/ \/
//	!!

void saveas(TCanvas* _c, string name_input, string MainTitle_text, double title_mar){

	gStyle->SetTextFont(42);
	TLatex data_presa_dati;
	data_presa_dati.SetTextSize(0.03);
	data_presa_dati.SetTextAlign(31);
	data_presa_dati.DrawLatexNDC(0.94, 0.91, "dati 2020/12/16, g = 9.8055 m/s^{2}");
	TLatex header;
	header.SetTextSize(0.04);
	header.DrawLatexNDC(title_mar, 0.91, MainTitle_text.c_str());

	// save plot figure in ./fig/ directory
	int slash=name_input.find_last_of("/");
	int dot=name_input.find_last_of(".");
	string filename="../fig/fig_"+name_input.substr(slash+1, dot-slash-1)+".pdf";
	_c->SaveAs(filename.c_str());
}

// Verifica della compatibilità per grandezze con errore ASSOLUTO
bool test_absErr(double g1, double g2, double eg1, double eg2, ofstream out){
	bool r;
	if ((abs(g1-g2)<(eg1+eg2))){
		out<<"COMPATIBILITA'"<<endl;
		r=true;
	}else{
		out<<"DISCREPANZA"<<endl;
		r=false;
	}
	return r;
}

// Verifica della compatibilità per grandezze con errore STATISTICO
// Entrambe le misure devono avere errore sistematico!
// Criterio del 3(sigma)
string test_statErr(double g1, double g2, double eg1, double eg2){
	string r;
	auto r_num=abs(g1-g2)-(3*sqrt((eg1*eg1)+(eg2*eg2)));
	if ((abs(g1-g2)<(3*sqrt((eg1*eg1)+(eg2*eg2))))){
		r="COMPATIBILITA'";
	}else{
		r="DISCREPANZA: scarto tra |g1-g2| e |eg1+eg2| = "+to_string(abs(r_num)) ;
	}
	return r;
}


// main function
int main(int argc, char** argv)
{
	// initial setup
    TApplication app("app", 0, 0);
	/*	NON TOCCARE SOPRA:	setup iniziale, lancia applicazione root
	 */

   	//TCanvas mainPlot("mainPlot", "", 600, 500);	// IMPOSTARE w, h
    //mainPlot.SetMargin(0.08, 0.06, 0.10, 0.10); 	// Set canvas size and borders

	/////////////////////////////////////////////////////////// BEGIN MAIN FUNCTION
	/////////////////////////////////////////////////////////// BEGIN MAIN FUNCTION

    // string __input_main="../dati/dati_C03_201222_presa_dati1_v1_LOCKED.txt";
	// ifstream in_dati(__input_main.c_str());	// ------------------------- MAIN INPUT FILE
	if(argc<2){

        cerr<<"Input format: ./analisi_dati ../dati/<name_file> <n.o of pointctr>"<<endl;
        return 1;
    }
    if(argc<3){

        cerr<<"Missing <n.o of pointctr>!"<<endl;
        return 2;
    }

	ifstream in_dati(argv[1]);
    int PointCtr=stoi(argv[2]); // Str to Int -> StoI
    cout<<PointCtr<<endl<<endl;

	double x, d0, m;
	in_dati>>x>>d0>>m;
	double d=d0*1e-3;

	double eL0, e_t, e_d, e_m;
	in_dati>>eL0>>e_t>>e_d>>e_m;




	TCanvas c("c", "", 600, 500);
	c.SetMargin(0.12, 0.08, 0.12, 0.10);

	TGraphErrors _g1;
	_g1.GetXaxis()->SetTitle("Lunghezza L_{i} (m)");
	_g1.GetYaxis()->SetTitle("Peiodo T_{i} (s)");
	_g1.GetXaxis()->SetTitleOffset(0.85);
	_g1.GetXaxis()->SetTitleSize(0.05);
	_g1.GetYaxis()->SetTitleSize(0.05);

	for(int i=0; i<PointCtr; i++){

		string txt;
		in_dati>>txt;
		double L_i;
		in_dati>>L_i;
		double L=sqrt(pow(L_i*1e-3, 2)+pow((d)/(double)2, 2));
		double eL=((abs(d/(2*sqrt(d*d+4*L*L)))*eL0*1e-3)+(abs(2*L/sqrt(d*d+4*L*L)))*e_d*1e-3)/sqrt(3);
		in_dati>>txt;

		double t_10;
		vector<double> t10_v;
		for(int j=0; j<10; j++){

			in_dati>>t_10;
			t10_v.push_back(t_10/10);
		}

		_g1.SetPoint(i, L, Media(t10_v));
		_g1.SetPointError(i, eL, ErroreStandard(t10_v));
		t10_v.clear();
	}

	TF1 f1("f", "[2]+2*[1]*sqrt(x/[0])", 1.0, 2.0);
	f1.SetParameter(2, 0);
	f1.SetParameter(0, 10);
	f1.FixParameter(1, M_PI);

	_g1.Draw("ap");
	_g1.Fit("f");


	gStyle->SetTextFont(42);
	TLatex data_presa_dati;
	data_presa_dati.SetTextSize(0.03);
	data_presa_dati.SetTextAlign(31);
	data_presa_dati.DrawLatexNDC(0.92, 0.91, "dati 2020/12/22, offset #neq 0");
	TLatex header;
	header.SetTextSize(0.035);
	header.DrawLatexNDC(0.12, 0.91, "#bf{periodo/lunghezza PENDOLO}");

	string chi2_s="#bf{#chi^{2}/ndf			"+to_string(f1.GetChisquare())+"/"+to_string((int)f1.GetNDF())+"}";
	gStyle->SetTextFont(42);
	TLatex chi2;
	chi2.SetTextSize(0.04);
	chi2.SetTextAlign(31);
	chi2.DrawLatexNDC(0.88, 0.16, chi2_s.c_str());

    string filein=argv[1];
    int slash=filein.find_last_of("/");
    int dot=filein.find_last_of(".");
	string save="../fig/"+filein.substr(slash+1, dot-slash-1)+"_wOffset.pdf";
	c.SaveAs(save.c_str());

    cout<<endl<<"X^2/ndf (prob.) = "<<f1.GetChisquare()<<"/"<<f1.GetNDF()<<" ("<<f1.GetProb()<<")"<<endl;


	app.Run();	///////////////////////////////////////////////////////////END OF MAIN FUNCTION
    return 0;	///////////////////////////////////////////////////////////END OF MAIN FUNCTION
}